# Test the collapse function using randomly generated unit tests

# First, generate 6 sequences, 3 of which will be collapsed

# Generate 3 random ones
set.seed(42)
seqs0 = random_sequences(20, 3)
# And then from the first one
#  1) shift one by 2nt left
#  2) shift one by 3nt right
#  3) sub-string sequence
seqs = c(
   seqs0,
   paste(c(substring(seqs0[3], 3, 20), sample(c('A', 'C', 'G', 'T'), 2)), collapse=''),
   paste(c(sample(c('A', 'C', 'G', 'T'), 3), substring(seqs0[3], 1, 17)), collapse=''),
   substring(seqs0[3], 3, 18),
   paste(c(substring(seqs0[1], 3, 20), sample(c('A', 'C', 'G', 'T'), 2)), collapse='')
)

#fasta_writer(1:length(seqs), seqs, '~/cloud/research/microbiome/himap/collapse_test.fasta')

# Generate abundance table out of these sequences. We don't really need
# FASTA file here.

ab_in = matrix(c(1:14), nrow=2)
rownames(ab_in) = c('sample1', 'sample2')
colnames(ab_in) = seqs


