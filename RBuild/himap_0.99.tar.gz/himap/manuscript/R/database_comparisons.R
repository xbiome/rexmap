library(data.table)
library(ggplot2)

# Load main comparison table
main_path = '~/cloud/research/microbiome/himap/manuscript/'
setwd(main_path)

comp.dt = fread('supplement/databases_comparisons.txt')
comp.dt[, database := factor(database, levels=rev(.SD[rank=='strain', database]))]

simpleCap = Vectorize(function(x) {
  s = strsplit(x, " ")[[1]]
  paste(toupper(substring(s, 1,1)), substring(s, 2),
      sep="", collapse=" ")
}, 'x')

comp.plot = ggplot(comp.dt, aes(y=uniques, x=database, fill=database)) +
   facet_wrap(~ simpleCap(rank), ncol=1, scales='free_x') +
   geom_col(position='dodge') +
   scale_y_continuous('number of unique ranks', expand=c(0,0)) +
   scale_fill_brewer(palette='Dark2') +
   coord_flip() +
   theme(
      #axis.ticks.x=element_blank(),
      #axis.text.x=element_blank(),
      axis.text=element_text(color='black'),
      panel.background=element_blank(),
      axis.line=element_line(color='black'),
      strip.background=element_blank(),
      legend.position='none',
      plot.margin=margin(r=1, unit='cm'),
      # panel.border=element_rect(fill=NA, color='black'),
      panel.grid.major.y=element_blank()
   )
comp.plot
ggsave(file.path(main_path, 'database_comparisons_barplot.pdf'),
       width=3.5, height=4.5)
