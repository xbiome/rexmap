# SILVA database

Generating statistics based on the SILVA_132_SSURef_tax_silva.fasta. First extract all
entries that have species identfication:

```sh
isegota@skynet:~/data1/databases/silva
$ awk '$0 ~ "^>" { 
	split($0, a, ";"); 
	if (a[7] !~ "[Uu][nidentified|ncultured]" && a[7] !~ " [Bb]acterium" && 
	    a[7] !~ "Bacterium" && a[7] !~ "^[Bb]acterium" && a[7] ~ " " && 
	    a[7] !~ "^[a-z]") { 
	    	sub("Candidatus[ ]?", "", a[7]); 
	    	sub("\\[", "", a[7]); 
	    	sub("\\]", "", a[7]); 
	    	print a[7] 
	 } }' SILVA_132_SSURef_tax_silva.fasta | sort | uniq > SILVA_132_SSURef_tax_silva_species.txt

```

This will give us a list of unique strains and species that have no strain designation. Extract only strains:
```sh
isegota@skynet:~/data1/databases/silva

awk '$0 ~ "[^ ]+ [^ ]+ .*" { print $0 }' SILVA_132_SSURef_tax_silva_species.txt > SILVA_132_SSURef_tax_silva_strains.txt
```
